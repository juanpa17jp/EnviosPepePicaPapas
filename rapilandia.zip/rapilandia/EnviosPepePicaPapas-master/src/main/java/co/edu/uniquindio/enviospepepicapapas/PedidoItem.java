package co.edu.uniquindio.enviospepepicapapas;

public interface PedidoItem {
    double calcularCosto();
}

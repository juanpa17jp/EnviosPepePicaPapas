package co.edu.uniquindio.enviospepepicapapas;

public interface NotificacionSender {
    void enviarNotificacion(String mensaje, String destino);
}

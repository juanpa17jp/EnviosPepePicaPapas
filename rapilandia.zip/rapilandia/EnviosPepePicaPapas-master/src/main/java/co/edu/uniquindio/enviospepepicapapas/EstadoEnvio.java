package co.edu.uniquindio.enviospepepicapapas;

public enum EstadoEnvio {
    SOLICITADO,
    ASIGNADO,
    ENTREGADO,
    ENRUTA,
    INCIDENCIA
}

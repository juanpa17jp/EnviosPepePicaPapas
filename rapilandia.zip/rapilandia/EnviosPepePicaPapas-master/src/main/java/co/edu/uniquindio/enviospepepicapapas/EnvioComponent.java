package co.edu.uniquindio.enviospepepicapapas;

public interface EnvioComponent {
    double calcularTarifa(Envio envio);
}

package co.edu.uniquindio.enviospepepicapapas;

import java.time.LocalDate;

public class Pago {
    private int idPago;
    private double monto;
    private LocalDate fecha;
    private String resultado;
    private MetodoPago metodo;

}

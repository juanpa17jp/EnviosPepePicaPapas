package co.edu.uniquindio.enviospepepicapapas;

public interface TarifaStrategy {
    double calcularTarifa(Envio envio);
}

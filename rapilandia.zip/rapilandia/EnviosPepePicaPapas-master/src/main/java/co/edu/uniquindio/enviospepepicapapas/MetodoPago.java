package co.edu.uniquindio.enviospepepicapapas;

public interface MetodoPago {
    boolean procesarPago(double monto);
}

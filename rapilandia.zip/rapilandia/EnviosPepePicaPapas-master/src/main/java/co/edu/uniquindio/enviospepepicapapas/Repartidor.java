package co.edu.uniquindio.enviospepepicapapas;

public class Repartidor extends Usuario {

}

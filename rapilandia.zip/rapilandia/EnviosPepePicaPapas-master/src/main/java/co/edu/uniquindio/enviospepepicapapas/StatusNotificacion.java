package co.edu.uniquindio.enviospepepicapapas;

public enum StatusNotificacion {
    PENDIENTE,
    ENVIADA,
    FALLIDA
}

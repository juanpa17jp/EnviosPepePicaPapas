package co.edu.uniquindio.enviospepepicapapas;

public class PagoTarjeta implements MetodoPago{
    private String numeroTarjeta;

    public boolean procesarPago(double costo) {
        return false;
    }

}
